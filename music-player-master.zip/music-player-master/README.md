

# music-player
## (https://amangupta262.github.io/music-player/)

- A music player user interface created using **HTML and CSS only**.



#### Home Page

- **Screen size > 992px**

![](ss/1.png)

![](ss/2.png)

![](ss/3.png)

![](ss/4.png)



- **Screen size > 768px**

![](ss/6.png)

![](ss/7.png)



- **Screen size > 576px**

![](ss/9.png)

![](ss/10.png)



#### Single Playlist

- **Screen size > 992px**

![](ss/5.png)

- **Screen size > 576px**

![](ss/8.png)